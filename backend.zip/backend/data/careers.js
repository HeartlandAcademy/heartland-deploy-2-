const careers = [
  {
    title: "This is Random Job Title",
    careerCategory: "Teaching",
    noOfVacancy: 10,
    employmentType: "Full Time",
    location: "Kathmandu Nepal",
    offeredSalary: "Negotiable",
    applyBefore: "2023-10-19",
    educationLevel: "Masters",
    experienceRequired: "4+ years",
    careerSpecs:
      "Mature & evolved professional with relevant expertise in the related field",
    careerDesc:
      "Developing and fostering the appropriate skills and social abilities to enable the optimum development of pupils.",
    note: "Salary No Bar for the right Candidate. Our Remuneration is best in the industry.",
  },
  {
    title: "This is Random Job Title 2",
    careerCategory: "Teaching",
    noOfVacancy: 10,
    employmentType: "Full Time",
    location: "Kathmandu Nepal",
    offeredSalary: "Negotiable",
    applyBefore: "2023-10-19",
    educationLevel: "Masters",
    experienceRequired: "4+ years",
    careerSpecs:
      "Mature & evolved professional with relevant expertise in the related field",
    careerDesc:
      "Developing and fostering the appropriate skills and social abilities to enable the optimum development of pupils.",
    note: "Salary No Bar for the right Candidate. Our Remuneration is best in the industry.",
  },
  {
    title: "This is Random Job Title 3",
    careerCategory: "Teaching",
    noOfVacancy: 10,
    employmentType: "Full Time",
    location: "Kathmandu Nepal",
    offeredSalary: "Negotiable",
    applyBefore: "2023-10-19",
    educationLevel: "Masters",
    experienceRequired: "4+ years",
    careerSpecs:
      "Mature & evolved professional with relevant expertise in the related field",
    careerDesc:
      "Developing and fostering the appropriate skills and social abilities to enable the optimum development of pupils.",
    note: "Salary No Bar for the right Candidate. Our Remuneration is best in the industry.",
  },
  {
    title: "This is Random Job Title 4",
    careerCategory: "Teaching",
    noOfVacancy: 10,
    employmentType: "Full Time",
    location: "Kathmandu Nepal",
    offeredSalary: "Negotiable",
    applyBefore: "2023-10-19",
    educationLevel: "Masters",
    experienceRequired: "4+ years",
    careerSpecs:
      "Mature & evolved professional with relevant expertise in the related field",
    careerDesc:
      "Developing and fostering the appropriate skills and social abilities to enable the optimum development of pupils.",
    note: "Salary No Bar for the right Candidate. Our Remuneration is best in the industry.",
  },
  {
    title: "This is Random Job Title 5",
    careerCategory: "Teaching",
    noOfVacancy: 10,
    employmentType: "Full Time",
    location: "Kathmandu Nepal",
    offeredSalary: "Negotiable",
    applyBefore: "2023-10-19",
    educationLevel: "Masters",
    experienceRequired: "4+ years",
    careerSpecs:
      "Mature & evolved professional with relevant expertise in the related field",
    careerDesc:
      "Developing and fostering the appropriate skills and social abilities to enable the optimum development of pupils.",
    note: "Salary No Bar for the right Candidate. Our Remuneration is best in the industry.",
  },
];

export default careers;
