const carousel = [
  {
    title: "Australian Ambassador",
    description: "STEM inauguration Program by his excellency Mr. Peter Budd",
    image: "java.jpeg",
  },
  {
    title: "Australian Ambassador 12",
    description: "STEM inauguration Program by his excellency Mr. Peter Budd",
    image: "java123.jpeg",
  },
  {
    title: "Australian Ambassador 60",
    description: "STEM inauguration Program by his excellency Mr. Peter Budd",
    image: "java54564.jpeg",
  },
];

export default carousel;
