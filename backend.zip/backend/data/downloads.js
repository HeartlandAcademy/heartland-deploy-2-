const downloads = [
  {
    title: "This is Downloads 1",
    originalFile: "dsasdasd",
    file: "dsfsdfsdf",
  },
  {
    title: "This is Downloads 2",
    originalFile: "dsasdasd",
    file: "dsfsdfsdf",
  },
];

export default downloads;
