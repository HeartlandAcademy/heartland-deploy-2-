const modal = [
  {
    image: "java.jpeg",
  },
];

export default modal;
