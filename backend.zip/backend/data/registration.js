const registration = [
  {
    firstName: "Bob",
    lastName: "Marley",
    email: "bob123@gmail.com",
    phone: "9899999991",
    queries: "sdfsdf sd fsd fsd fsd fsdf sdfsfewrerwe sdfw ew fesdf sdf sdf",
  },
  {
    firstName: "Bob",
    lastName: "Marley",
    email: "bob123@gmail.com",
    phone: "9899999991",
    queries: "sdfsdf sd fsd fsd fsd fsdf sdfsfewrerwe sdfw ew fesdf sdf sdf",
  },
  {
    firstName: "Bob",
    lastName: "Marley",
    email: "bob1235@gmail.com",
    phone: "9899999991",
    queries: "sdfsdf sd fsd fsd fsd fsdf sdfsfewrerwe sdfw ew fesdf sdf sdf",
  },
];

export default registration;
