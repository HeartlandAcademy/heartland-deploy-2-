const staffs = [
  {
    fullName: "Karan Singh Goyala",
    email: "goyalakaran145@gmail.com",
    phone: "9841577946",
  },
  {
    fullName: "Chanda karki",
    email: "goyalakaran1451@gmail.com",
    phone: "9841577946",
  },
  {
    fullName: "Bhim Singh Saud",
    email: "goyalakaran1452@gmail.com",
    phone: "9841577946",
  },
];

export default staffs;
