const teams = [
  {
    image: "asdasd",
    fullName: "Random Name",
    desc: "Random Desc",
  },
  {
    image: "asdasd",
    fullName: "Random Name",
    desc: "Random Desc",
  },
  {
    image: "asdasd",
    fullName: "Random Name",
    desc: "Random Desc",
  },
  {
    image: "asdasd",
    fullName: "Random Name",
    desc: "Random Desc",
  },
  {
    image: "asdasd",
    fullName: "Random Name",
    desc: "Random Desc",
  },
  {
    image: "asdasd",
    fullName: "Random Name",
    desc: "Random Desc",
  },
  {
    image: "asdasd",
    fullName: "Random Name",
    desc: "Random Desc",
  },
];

export default teams;
