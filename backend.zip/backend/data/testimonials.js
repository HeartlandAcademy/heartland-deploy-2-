const testimonials = [
  {
    students: [
      {
        fullName: "Random Name",
        image: "asdasd",
        desc: "Studen Grade 10",
        message:
          "I can't hope to properly express my gratitude for you allowing us into your amazing school. . It's an unbelievable school with an atmosphere that encourages creativity and a love of learning. I feel very lucky to have spent those days at Heartland, and I could've only wished to have been able to stay there longer.",
      },
      {
        fullName: "Random Name",
        image: "asdasd",
        desc: "Studen Grade 10",
        message:
          "I can't hope to properly express my gratitude for you allowing us into your amazing school. . It's an unbelievable school with an atmosphere that encourages creativity and a love of learning. I feel very lucky to have spent those days at Heartland, and I could've only wished to have been able to stay there longer.",
      },
      {
        fullName: "Random Name",
        image: "asdasd",
        desc: "Studen Grade 10",
        message:
          "I can't hope to properly express my gratitude for you allowing us into your amazing school. . It's an unbelievable school with an atmosphere that encourages creativity and a love of learning. I feel very lucky to have spent those days at Heartland, and I could've only wished to have been able to stay there longer.",
      },
      {
        fullName: "Random Name",
        image: "asdasd",
        desc: "Studen Grade 10",
        message:
          "I can't hope to properly express my gratitude for you allowing us into your amazing school. . It's an unbelievable school with an atmosphere that encourages creativity and a love of learning. I feel very lucky to have spent those days at Heartland, and I could've only wished to have been able to stay there longer.",
      },
    ],
    visitors: [
      {
        fullName: "Random Name",
        image: "asdasd",
        desc: "Studen Grade 10",
        message:
          "I can't hope to properly express my gratitude for you allowing us into your amazing school. . It's an unbelievable school with an atmosphere that encourages creativity and a love of learning. I feel very lucky to have spent those days at Heartland, and I could've only wished to have been able to stay there longer",
      },
      {
        fullName: "Random Name",
        image: "asdasd",
        desc: "Studen Grade 10",
        message:
          "I can't hope to properly express my gratitude for you allowing us into your amazing school. . It's an unbelievable school with an atmosphere that encourages creativity and a love of learning. I feel very lucky to have spent those days at Heartland, and I could've only wished to have been able to stay there longer",
      },
      {
        fullName: "Random Name",
        image: "asdasd",
        desc: "Studen Grade 10",
        message:
          "I can't hope to properly express my gratitude for you allowing us into your amazing school. . It's an unbelievable school with an atmosphere that encourages creativity and a love of learning. I feel very lucky to have spent those days at Heartland, and I could've only wished to have been able to stay there longer",
      },
      {
        fullName: "Random Name",
        image: "asdasd",
        desc: "Studen Grade 10",
        message:
          "I can't hope to properly express my gratitude for you allowing us into your amazing school. . It's an unbelievable school with an atmosphere that encourages creativity and a love of learning. I feel very lucky to have spent those days at Heartland, and I could've only wished to have been able to stay there longer",
      },
      {
        fullName: "Random Name",
        image: "asdasd",
        desc: "Studen Grade 10",
        message:
          "I can't hope to properly express my gratitude for you allowing us into your amazing school. . It's an unbelievable school with an atmosphere that encourages creativity and a love of learning. I feel very lucky to have spent those days at Heartland, and I could've only wished to have been able to stay there longer",
      },
      {
        fullName: "Random Name",
        image: "asdasd",
        desc: "Studen Grade 10",
        message:
          "I can't hope to properly express my gratitude for you allowing us into your amazing school. . It's an unbelievable school with an atmosphere that encourages creativity and a love of learning. I feel very lucky to have spent those days at Heartland, and I could've only wished to have been able to stay there longer",
      },
      {
        fullName: "Random Name",
        image: "asdasd",
        desc: "Studen Grade 10",
        message:
          "I can't hope to properly express my gratitude for you allowing us into your amazing school. . It's an unbelievable school with an atmosphere that encourages creativity and a love of learning. I feel very lucky to have spent those days at Heartland, and I could've only wished to have been able to stay there longer",
      },
      {
        fullName: "Random Name",
        image: "asdasd",
        desc: "Studen Grade 10",
        message:
          "I can't hope to properly express my gratitude for you allowing us into your amazing school. . It's an unbelievable school with an atmosphere that encourages creativity and a love of learning. I feel very lucky to have spent those days at Heartland, and I could've only wished to have been able to stay there longer",
      },
      {
        fullName: "Random Name",
        image: "asdasd",
        desc: "Studen Grade 10",
        message:
          "I can't hope to properly express my gratitude for you allowing us into your amazing school. . It's an unbelievable school with an atmosphere that encourages creativity and a love of learning. I feel very lucky to have spent those days at Heartland, and I could've only wished to have been able to stay there longer",
      },
      {
        fullName: "Random Name",
        image: "asdasd",
        desc: "Studen Grade 10",
        message:
          "I can't hope to properly express my gratitude for you allowing us into your amazing school. . It's an unbelievable school with an atmosphere that encourages creativity and a love of learning. I feel very lucky to have spent those days at Heartland, and I could've only wished to have been able to stay there longer",
      },
    ],
  },
];

export default testimonials;
