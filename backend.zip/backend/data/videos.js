const videos = [
  {
    src: "4Ga55qyPqfo",
  },
  {
    src: "E7OuEiasd0g",
  },
  {
    src: "VHZY97tecQk",
  },
  {
    src: "eR3vuwBkJgw",
  },
  {
    src: "4Ga55qyPqfo",
  },
  {
    src: "E7OuEiasd0g",
  },
];

export default videos;
